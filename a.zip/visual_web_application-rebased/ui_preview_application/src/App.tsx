// ui_preview_application/src/App.tsx
import { PreviewApp } from '../../visual_web_application/src/embedded';

export default function App() {
    return (
        <PreviewApp jsonUrl="/items.json" isStandalone={true} />
    );
}